from matplotlib import pyplot as plt
from matplotlib import style
import numpy as np

style.use('ggplot')

x,y = np.loadtxt('final.txt',
                 unpack=True,
                 delimiter = '\t')

plt.plot(x,y)

plt.title('Energy Consuption')
plt.ylabel('Energy (kWh)')
plt.xlabel('Hours')

plt.show()


